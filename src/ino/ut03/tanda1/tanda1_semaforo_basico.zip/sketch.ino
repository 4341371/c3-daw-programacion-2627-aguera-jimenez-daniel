#define LEDR 4 // led rojo
#define LEDA 3 // led amarillo
#define LEDV 2 // led verde
#define BTN1 7 // botón de pulsación

void setup() //Método que se ejecuta al inicio
{
  //Establecer modos de cada puerto
  //Salidas para leds
  pinMode(LEDR, OUTPUT);
  pinMode(LEDA, OUTPUT);
  pinMode(LEDV, OUTPUT);
  //Entrada para botón
  pinMode(BTN1, INPUT);

  //Apagar todos leds inicialmente
  digitalWrite(LEDR,LOW);
  digitalWrite(LEDA,LOW);
  digitalWrite(LEDV,LOW);
}

void loop() // Método que se ejecuta en bucle
{
  if (digitalRead(BTN1))
  {
    for (int i=0;i<3;i++)
    {
      digitalWrite(LEDR, HIGH);
      delay(500);
      digitalWrite(LEDR, LOW);
      delay(500);
    }
  }
  
}
